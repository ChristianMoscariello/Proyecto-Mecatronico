#ifndef SIMULATOR_H
#define SIMULATOR_H

void simulateDroneMotion();

#endif
